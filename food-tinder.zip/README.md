# Food Tinder - frontend

## Inicjalizacja

- Do poprawnego działania aplikacji należy zainstalować backend i go włączyć zgodnie z readme backendu
- należy wpisać komendę [npm install]
- następnie należy wpisać komendę npm run web (preview przeglądarkowy, jeśli chcą państwo zobaczyć na telefonie należy wpisać npm run android / npm run ios)
- aplikacja będzie dostępna na http://localhost:8081/
- należy włączyć narzędzia deweloperskie i ustawić widok na telefon by widzieć jak aplikacja wygląda normalnie.
